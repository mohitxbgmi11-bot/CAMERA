<?php
$config = [
    'bot_token' => '8811798884:AAHHt7tJB3Ix3R20ZD8s-XgF1vheLOErGZE',
    'chat_id'   => '8836279445',
    'website'   => 'https://yoursomin.com/',
    'admin_username' => 'anish',
    'admin_password' => 'exploits123'
];
?>